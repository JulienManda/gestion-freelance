export const API_URL = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000';

export const api = (path) => `${API_URL}/api/${path}`;